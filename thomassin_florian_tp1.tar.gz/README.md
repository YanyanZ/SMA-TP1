SMA-TP1
=======

Système multi-agent TP1 - UCAQ

Compilation:
CXX=clang++ cmake .
or
cmake .

Launch:
./start.sh
